package org.com.model;

public class DriverVO {
String fname;
String lname;
int age;
String gender;
long Phone;
String curr_loc;
String dest;
String city;
String start_time;
String end_time;
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}

public long getPhone() {
	return Phone;
}
public void setPhone(long phone) {
	Phone = phone;
}
public String getCurr_loc() {
	return curr_loc;
}
public void setCurr_loc(String curr_loc) {
	this.curr_loc = curr_loc;
}
public String getDest() {
	return dest;
}
public void setDest(String dest) {
	this.dest = dest;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getStart_time() {
	return start_time;
}
public void setStart_time(String start_time) {
	this.start_time = start_time;
}
public String getEnd_time() {
	return end_time;
}
public void setEnd_time(String end_time) {
	this.end_time = end_time;
}


	
}

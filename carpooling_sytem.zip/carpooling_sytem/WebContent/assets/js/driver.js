function ride_history() {
  document.getElementById("ride_history").style.display = "block";
}
